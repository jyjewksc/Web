from turtle import down
from flask import Flask, render_template, request, url_for
from flask_moment import Moment
from pathlib import Path
import uuid
# import sys 
import pandas as pd
import recognition.videodownload as download
import recognition.preprocessing as preprocessing
import recognition.load_model as model

# 需先在music-main/static/musicfile/下建立mp4、wav兩個資料夾 
app = Flask(__name__)
moment = Moment(app)

UPLOAD_FOLDER = Path(__file__).resolve().parent/'static/musicfile/mp4'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# get: 使用者輸入url
# post: 獲取url、下載、分析
@app.route('/', methods=['GET', 'POST'])
def get_url():
    # 使用者輸入url
    if request.method == "GET":
        return render_template('file.html', page_header="UPLOAD MUSIC")
    elif request.method == "POST":
        # 獲取url
        text = request.form['url']
        filename = str(uuid.uuid4())
        
        # 下載mp4
        download.download(text,filename)

        # preprocessing
        preprocessing.preprocessing_file(filename)

        # analysis
        result_df = model.predict_ans(filename)
        df = pd.DataFrame(result_df)
        result_list = df.values.tolist()

        return result_list


if __name__ == "__main__":
    app.run(debug=True)

from pytube import Playlist
from moviepy.editor import *
from pydub import AudioSegment
from pydub.utils import make_chunks
from pydub import AudioSegment
import os, re
import random
import math
import pandas as pd
import sys
from pytube import YouTube

def download(videourl,file_name):
    yt = YouTube(videourl)
    progMP4 = yt.streams.filter(progressive=True, file_extension='mp4')   # 設定下載方式及格式
    targetMP4 = progMP4.order_by('resolution').desc().first()  # 由畫質高排到低選畫質最高的來下載
    # targetMP4 = yt.streams.filter(progressive=True, file_extension='mp4')   # 設定下載方式及格式
    name = '%s.mp4' % (file_name)  # 給下載影片名
    video_file = targetMP4.download(output_path='/static/musicfile/mp4/%s' %(file_name) , filename=name) # 下載影片並給輸出路徑    
    

if __name__ == "__main__":
    # print('=================')
    # print(sys.argv[2])
    videourl = 'https://www.youtube.com/watch?v=CH50zuS8DD0&ab_channel=AdamEschborn'
    file_name = 'MM'
    download(videourl,file_name)
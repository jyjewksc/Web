from turtle import down
from flask import Flask, render_template, request, url_for
from flask_moment import Moment
from datetime import datetime
from pathlib import Path
import uuid
import sys 
import os
# practice start
import recognition.videodownload as download
import recognition.preprocessing as preprocessing
import recognition.load_model as model
# practice end

app = Flask(__name__)
moment = Moment(app)

# practice start

UPLOAD_FOLDER = Path(__file__).resolve().parent/'static/musicfile/uploaded'
# >> C:\Flask\music-main\static\musicfile\wav
# practice end


app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB

# @app.route('/')
# def index():
#     return render_template('index.html',
#                            page_header="page_header",
#                            current_time=datetime.utcnow())

# url
'''
@app.route('/', methods=['GET', 'POST'])
def get_file():
    if request.method == "GET":
        return render_template('file.html', page_header="upload music")
    elif request.method == "POST":
        
        return print('file.html')
        # download('file.html'.input)
        # file = request.files['file']
        # if file:
        #     ()
        #     # filename = str(uuid.uuid4())+"_"+file.filename
        #     # file.save(app.config['UPLOAD_FOLDER']/filename)
            
        #     preprocessing(file) # 切好並存出30s 3s 音樂檔

        #     file3s = 'filepath' # 切完音樂檔之後是否隨機獲取其中一段3S音樂，是的話需要寫一段隨機獲取的程式碼
        #     with open(file3s, 'r') as f:
        #         predict = model.predict_ans(f)
            
        #     return render_template('analysis.html', page_header="music analysis", predict = predict, src = url_for('static', filename=f'uploaded/{filename}'))
'''   
# file
@app.route('/', methods=['GET', 'POST'])
def get_file():
    if request.method == "GET":
        return render_template('file.html', page_header="upload music")
    elif request.method == "POST":
        file = request.files['file']
        if file:
            # save file
            filename = str(uuid.uuid4())+"_"+file.filename
            wav_outputpath = (app.config['UPLOAD_FOLDER']) 
            # UPLOAD_FOLDER = Path(__file__).resolve().parent/'static/musicfile/wav'
            # >> C:\Flask\music-main\static\musicfile\wav

            if not os.path.isdir(wav_outputpath):
                os.mkdir(wav_outputpath)
            
            file.save(wav_outputpath)
           
            # preprocess: wav/3s/30s
            # 切好並存出30s 3s音樂檔
            # preprocessing.preprocessing_wav(file.filename) 
            

        #     file3s = 'filepath' # 切完音樂檔之後是否隨機獲取其中一段3S音樂，是的話需要寫一段隨機獲取的程式碼
        #     with open(file3s, 'r') as f:
        #         predict = model.predict_ans(f)
            
            # return render_template('analysis.html', page_header="music analysis", predict = file.filename)
        return 'good'
if __name__ == "__main__":
    app.run(debug=True,port=5001)
